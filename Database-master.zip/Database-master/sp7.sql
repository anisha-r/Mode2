
SET autocommit = OFF

select * from student 

delete from student where sno=2

commit 

rollback 

alter table student drop column sub2