use sqlpractice;

Create Table Users
(
   username varchar(30) primary key,
   password varchar(30)
);

Insert into users values('Laksh','Laksh'),
   ('Kiruba','Laxmi'),
   ('Anubhav','Anand'),
   ('Venkat','Sai'),
   ('Darshini','Priya');
   
   select * from users