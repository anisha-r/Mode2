use bank

select * from accounts
update accounts set status='inactive' where accountno=1