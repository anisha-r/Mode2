use sqlpractice;

Create Table Employ
(
    Empno int,
    Name varchar(50), 
    Dept varchar(30),
    Desig varchar(30),
    Basic INT,
    primary key(Empno)
);



Insert into Employ values
(1,'kiran kumar kailasam','java','developer',42233),
(2,'Vishnu Vardhan Reddy','dotnet','programmer',42133),
(3,'Ram Kishan','java','developer',82233),
(4,'Kareem','dotnet','programmer',52234),
(5,'Sheik Sulthan Mohammad','dotnet','developer',42555)

desc employ

select * from employ
