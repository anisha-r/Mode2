package com.anisha.bank;

public interface UserRepository  {

    public User ByUserName(String username);
    

}
